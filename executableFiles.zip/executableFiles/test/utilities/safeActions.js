module.exports = {

    async click(elt, eltFriendlyName) {
        await elt.waitForClickable();
        await elt.click();
        if (eltFriendlyName !== undefined) {
            logger.info("Clicked on " + eltFriendlyName);
        }
    },

    async setValue(elt, value, eltFriendlyName) {
        await elt.waitForDisplayed();
        await elt.setValue(value);
        if (eltFriendlyName !== undefined) {
            logger.info("Entered " + value + " in " + eltFriendlyName);
        }
    },

    async addValue(elt, value, eltFriendlyName) {
        await elt.waitForDisplayed();
        await elt.addValue(value);
        if (eltFriendlyName !== undefined) {
            logger.info("Added value " + value + " in " + eltFriendlyName);
        }
    },

    async keys(elt, value, eltFriendlyName) {
        await this.click(elt,eltFriendlyName)
        await browser.keys(value);
        if (eltFriendlyName !== undefined) {
            logger.info("Entered keys " + value + " in " + eltFriendlyName);
        }
    },

    async url(URL) {
        await browser.url(URL);
        logger.info("Navigated to " + URL);
    },

    async isDisplayed(elt, eltFriendlyName) {
        let isDisplayed = await elt.isDisplayed();
        if (eltFriendlyName !== undefined) {
            logger.info(eltFriendlyName + " is displayed = " + isDisplayed);
        }
        return isDisplayed;
    },

    async waitForDisplayed(elt, eltFriendlyName) {
        await elt.waitForDisplayed({
            timeout: 10000,
            reverse: false,
            timeoutMsg: eltFriendlyName + " is still not displayed",
            interval: 500
        });
        if (eltFriendlyName !== undefined) {
            logger.info("Waited for " +eltFriendlyName + " to be displayed");
        }
    },

    async waitForDisplayedReverse(elt, eltFriendlyName) {
        await elt.waitForDisplayed({
            timeout: 10000,
            reverse: true,
            timeoutMsg: eltFriendlyName + " is still displayed",
            interval: 500
        });
        if (eltFriendlyName !== undefined) {
            logger.info("Waited for " +eltFriendlyName + " to be not displayed");
        }
    },
}