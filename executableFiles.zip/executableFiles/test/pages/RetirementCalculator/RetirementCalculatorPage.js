module.exports={

    //Age Section

    get currentAgeRequiredTextBox() {
        return $('//input[@id="current-age"]');
    },

    get agePlanToRetireRequiredTextBox() {
        return $('//input[@id="retirement-age"]');
    },

    //Income/Savings section

    get currentAnnualIncomeRequiredTextBox() {
        return $('//input[@id="current-income"]');
    },

    get spouseAnnualIncomeOptionalTextBox() {
        return $('//input[@id="spouse-income"]');
    },

    get currentRetirementSavingsBalanceRequiredTextBox() {
        return $('//input[@id="current-total-savings"]');
    },

    get currentRetirementSavingsEachYearRequiredTextBox() {
        return $('//input[@id="current-annual-savings"]');
    },

    get rateOfIncreaseInSavingsEachYearRequiredTextBox() {
        return $('//input[@id="savings-increase-rate"]');
    },

    //Social Security income section

    get includeSocialSecurityBenefitsYesRequiredRadioButton() {
        return $('//label[@for="yes-social-benefits"]');
    },

    get includeSocialSecurityBenefitsNoRequiredRadioButton() {
        return $('//label[@for="no-social-benefits"]');
    },

    get whatIsYourMaritalStatusQuestionText() {
        return $('//legend[contains(text(),"What is your marital") and contains(text(),"status?")]')
    },

    get maritalStatusMarriedRequiredRadioButton() {
        return $('//label[@for="married"]');
    },

    get socialSecurityOverrideAmountOptionalTextBox() {
        return $('//input[@id="social-security-override"]');
    },

    get calculateButton() {
        return $('//button[text()="Calculate"]');
    },

    //Default calculator values section
    get adjustDefaultValuesLink() {
        return $('//a[text()="Adjust default values"]');
    },

    get otherIncomeOptionalTextBox() {
        return $('//input[@id="additional-income"]');
    },

    get yearsPlanToDependOnRetirementIncomeOptionalTextBox() {
        return $('//input[@id="retirement-duration"]');
    },

    get incomeIncreaseWithInflationYesRadioButton() {
        return $('//label[@for="include-inflation"]');
    },

    get expectedInflationRateOptionalTextBox() {
        return $('//input[@id="expected-inflation-rate"]');
    },

    get annualIncomeAvailableEachYearOfRetirementOptionalTextBox() {
        return $('//input[@id="retirement-annual-income"]');
    },

    //Investment expectations section
    get preRetirementInvestmentReturnOptionalTextVox() {
        return $('//input[@id="pre-retirement-roi"]');
    },

    get postRetirementInvestmentReturnOptionalTextBox() {
        return $('//input[@id="post-retirement-roi"]');
    },

    get saveChangesButton() {
        return $('//button[text()="Save changes"]');
    },

    get defaultCalculatorValuesPopup() {
        return $('//h1[text()="Default calculator values"]/parent::div');
    },

    // Results Section
    get resultsHeader() {
        return $('//h3[text()="Results"]');
    }
}