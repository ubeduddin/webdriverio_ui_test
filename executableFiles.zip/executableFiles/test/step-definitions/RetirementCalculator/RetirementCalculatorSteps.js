let retirementCalculatorPage = require("./../../pages/RetirementCalculator/RetirementCalculatorPage.js");
let environmentData = require("./../../data/environmentData.json");
let chai = require('chai');
let expect = chai.expect;

Given(/^I navigate to retirement calculator page$/, async function () {
    await browser.reloadSession();
    await safeActions.url(environmentData.securian.retirementCalculator);
});

When(/^I answer as (.*) for the What is your current age required question$/, async function (currentAge) {
    await safeActions.setValue(retirementCalculatorPage.currentAgeRequiredTextBox, currentAge, "What is your current age? required question in Retirement Calculator Page");
});

When(/^I answer as (.*) for the At what age do you plan to retire required question$/, async function (agePlanToRetire) {
    await safeActions.setValue(retirementCalculatorPage.agePlanToRetireRequiredTextBox, agePlanToRetire, "At what age do you plan to retire? required question in Retirement Calculator Page");
});

When(/^I answer as (.*) for the What is your current annual income required question$/, async function (currentAnnualIncome) {
    await safeActions.keys(retirementCalculatorPage.currentAnnualIncomeRequiredTextBox, currentAnnualIncome, "What is your current annual income? required question in Retirement Calculator Page");
});

When(/^I answer as (.*) for the What is your spouse's annual income optional question$/, async function (spouseAnnualIncome) {
    await safeActions.keys(retirementCalculatorPage.spouseAnnualIncomeOptionalTextBox, spouseAnnualIncome, "What is your spouse's annual income? optional question in Retirement Calculator Page");
});

When(/^I answer as (.*) for the What is your current retirement savings balance required question$/, async function (currentRetirementSavingsBalance) {
    await safeActions.keys(retirementCalculatorPage.currentRetirementSavingsBalanceRequiredTextBox, currentRetirementSavingsBalance, "What is your current retirement savings balance? required question in Retirement Calculator Page");
});

When(/^I answer as (.*) for the How much are you currently saving each year for retirement required question$/, async function (currentRetirementSavingsEachYear) {
    await safeActions.setValue(retirementCalculatorPage.currentRetirementSavingsEachYearRequiredTextBox, currentRetirementSavingsEachYear, "How much are you currently saving each year for retirement? required question in Retirement Calculator Page");
});

When(/^I answer as (.*) for the What is the rate of increase in your savings each year required question$/, async function (rateOfIncreaseInSavingsEachYear) {
    await safeActions.setValue(retirementCalculatorPage.rateOfIncreaseInSavingsEachYearRequiredTextBox, rateOfIncreaseInSavingsEachYear, "What is the rate of increase in your savings each year? required question in Retirement Calculator Page");
});

When(/^I select Yes for the Should we include Social Security benefits required question$/, async function () {
    await safeActions.click(retirementCalculatorPage.includeSocialSecurityBenefitsYesRequiredRadioButton, "Yes radio button im Should we include Social Security benefits? required question in Retirement Calculator Page");
});

When(/^I select No for the Should we include Social Security benefits required question$/, async function () {
    await safeActions.click(retirementCalculatorPage.includeSocialSecurityBenefitsNoRequiredRadioButton, "No radio button in Should we include Social Security benefits? required question in Retirement Calculator Page");
});

When(/^I select Married for the What is your marital status required question$/, async function () {
    await safeActions.click(retirementCalculatorPage.maritalStatusMarriedRequiredRadioButton, "What is your marital status? required question in Retirement Calculator Page");
});

When(/^I fill (.*) in Social Security override amount optional field$/, async function (socialSecurityOverrideAmount) {
    await safeActions.keys(retirementCalculatorPage.socialSecurityOverrideAmountOptionalTextBox, socialSecurityOverrideAmount,"Social Security override amount field in Retirement Calculator Page");
});

When(/^I click on Calculate button$/, async function () {
    await safeActions.click(retirementCalculatorPage.calculateButton,"Calculate button in Retirement Calculator Page");
});

When(/^I click on Adjust default values link$/, async function () {
    await safeActions.click(retirementCalculatorPage.adjustDefaultValuesLink,"Adjust default values link in Retirement Calculator Page");
});

When(/^I answer as (.*) for the What other income will you have during retirement optional question$/, async function (otherIncome) {
    await safeActions.keys(retirementCalculatorPage.otherIncomeOptionalTextBox, otherIncome, "What other income will you have during retirement? Optional question in Retirement Calculator Page");
});

When(/^I answer as (.*) for the How many years do you plan to depend on retirement income optional question$/, async function (yearsPlanToDependOnRetirementIncome) {
    await safeActions.setValue(retirementCalculatorPage.yearsPlanToDependOnRetirementIncomeOptionalTextBox, yearsPlanToDependOnRetirementIncome, "How many years do you plan to depend on retirement income? Optional question in Retirement Calculator Page");
});

When(/^I select Yes for the Does your post-retirement income increase with inflation$/, async function () {
    await safeActions.click(retirementCalculatorPage.incomeIncreaseWithInflationYesRadioButton, "Does your post-retirement income increase with inflation? Optional question in Retirement Calculator Page");
});

When(/^I answer as (.*) for the If yes, what is the expected inflation rate optional question$/, async function (expectedInflationRate) {
    await safeActions.waitForDisplayed(retirementCalculatorPage.expectedInflationRateOptionalTextBox, "If yes, what is the expected inflation rate? Optional question in Retirement Calculator Page");
    await safeActions.setValue(retirementCalculatorPage.expectedInflationRateOptionalTextBox, expectedInflationRate, "If yes, what is the expected inflation rate? Optional question in Retirement Calculator Page");
});

When(/^I answer as (.*) for the How much of your final annual income do you want available in each year of your retirement optional question$/, async function (annualIncomeAvailableEachYearOfRetirement) {
    await safeActions.setValue(retirementCalculatorPage.annualIncomeAvailableEachYearOfRetirementOptionalTextBox, annualIncomeAvailableEachYearOfRetirement, "How much of your final annual income do you want available in each year of your retirement? Optional question in Retirement Calculator Page");
});

When(/^I fill (.*) in Pre-retirement investment return field$/, async function (preRetirementInvestmentReturn) {
    await safeActions.setValue(retirementCalculatorPage.preRetirementInvestmentReturnOptionalTextVox, preRetirementInvestmentReturn, "Pre-retirement investment return field in Retirement Calculator Page");
});

When(/^I fill (.*) in Post-retirement investment return field$/, async function (postRetirementInvestmentReturn) {
    await safeActions.setValue(retirementCalculatorPage.postRetirementInvestmentReturnOptionalTextBox, postRetirementInvestmentReturn, "Post-retirement investment return field in Retirement Calculator Page");
});

When(/^I click on Save changes button$/, async function () {
    await safeActions.click(retirementCalculatorPage.saveChangesButton,"Save changes button in Retirement Calculator Page");
});

Then(/^the results header is displayed$/, async function () {
    await safeActions.waitForDisplayed(retirementCalculatorPage.resultsHeader, "Results header after clicking Calculate in Retirement Calculator Page");
    let resultsHeaderIsDisplayed = await safeActions.isDisplayed(retirementCalculatorPage.resultsHeader, "Results header after clicking Calculate in Retirement Calculator Page");
    expect(resultsHeaderIsDisplayed).to.be.true;
});

Then(/^Additional Social Security fields should display$/, async function () {
    await safeActions.waitForDisplayed(retirementCalculatorPage.whatIsYourMaritalStatusQuestionText, "What is your marital status? question in Retirement Calculator Page");
    let whatIsYourMaritalStatusQuestionTextIsDisplayed = await safeActions.isDisplayed(retirementCalculatorPage.whatIsYourMaritalStatusQuestionText, "What is your marital status? question in Retirement Calculator Page");
    expect(whatIsYourMaritalStatusQuestionTextIsDisplayed).to.be.true;
});

Then(/^Additional Social Security fields should hide$/, async function () {
    await safeActions.waitForDisplayedReverse(retirementCalculatorPage.whatIsYourMaritalStatusQuestionText, "What is your marital status? question in Retirement Calculator Page");
    let whatIsYourMaritalStatusQuestionTextIsDisplayed = await safeActions.isDisplayed(retirementCalculatorPage.whatIsYourMaritalStatusQuestionText, "What is your marital status? question in Retirement Calculator Page");
    expect(whatIsYourMaritalStatusQuestionTextIsDisplayed).to.be.false;
});

When(/^Default calculator values popup is displayed$/, async function () {
    await safeActions.waitForDisplayed(retirementCalculatorPage.defaultCalculatorValuesPopup, "Default calculator popup in Retirement Calculator Page");
    let defaultCalculatorValuesPopupIsDisplayed = await safeActions.isDisplayed(retirementCalculatorPage.defaultCalculatorValuesPopup, "Default calculator popup in Retirement Calculator Page");
    expect(defaultCalculatorValuesPopupIsDisplayed).to.be.true;
});

Then(/^Default calculator values popup is closed$/, async function () {
    await safeActions.waitForDisplayedReverse(retirementCalculatorPage.defaultCalculatorValuesPopup, "Default calculator popup in Retirement Calculator Page");
    let defaultCalculatorValuesPopupIsDisplayed = await safeActions.isDisplayed(retirementCalculatorPage.defaultCalculatorValuesPopup, "Default calculator popup in Retirement Calculator Page");
    expect(defaultCalculatorValuesPopupIsDisplayed).to.be.false;
});